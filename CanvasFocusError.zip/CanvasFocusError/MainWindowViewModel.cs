﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CanvasFocusError
{
    public class MainWindowViewModel : BindableBase
    {
        private ICommand clickCommand;

        public ICommand ClickCommand => clickCommand ?? (clickCommand = new DelegateCommand( ExecuteClickCommand ));

        private Canvas container;

        public Canvas Container
        {
            get { return container; }
            set { SetProperty( ref this.container, value ); }
        }

        private double zoomValue;

        public double ZoomValue
        {
            get { return zoomValue; }
            set
            {
                if (SetProperty( ref zoomValue, value ))
                {
                }
            }
        }



        public MainWindowViewModel()
        {
            this.Init();
        }

        private void ExecuteClickCommand()
        {
            this.ZoomValue = new Random().NextDouble() * 10;
        }

        internal void Init()
        {
            Container = new Canvas
            {
                Background = new VisualBrush
                {
                    TileMode = TileMode.Tile,
                    Stretch = Stretch.Uniform,
                    Viewport = new System.Windows.Rect( 20, 20, 20, 20 ),
                    ViewportUnits = BrushMappingMode.Absolute,
                    Visual = new Rectangle { Width = 20, Height = 20, Fill = Brushes.Transparent, Stroke = Brushes.Gray, StrokeThickness = 0.1/*, Visibility = IsVisible*/ } //Visible Binding은 어떻게 해야 할까 ?
                },
                Width = 10000,
                Height = 10000
            };

            Container.MouseMove += Container_MouseMove;
            //ZoomValue = 1.0;
        }

        private void Container_MouseMove( object sender, MouseEventArgs e )
        {
            var cdn = Mouse.GetPosition( this.Container );
            //this.Coordinate = $"X:{cdn.X}, Y:{cdn.Y}";
        }
    }
}
